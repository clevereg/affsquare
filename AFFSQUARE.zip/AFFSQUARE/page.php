<?php
get_header();
include'content.php';
get_footer();