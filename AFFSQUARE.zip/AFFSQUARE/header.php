<?php 
wp_head();
include 'menu.php';
